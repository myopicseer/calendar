<?php

echo dirname(__FILE__);
?>