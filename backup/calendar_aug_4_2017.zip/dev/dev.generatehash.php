







<?php

$psw = password_hash('1buckeye', PASSWORD_BCRYPT);


echo $psw;